# -*- coding: utf-8 -*-

import pygame
import random
from pygame.locals import *
from sys import exit

pygame.init()
pygame.mixer.init()
pygame.mixer.music.load('./bin/music/With My Friend.mp3')
attacked_sound = pygame.mixer.Sound('./bin/music/10747.wav')
screen = pygame.display.set_mode((800,600),0,32)
pygame.display.set_caption('Initio')
pygame.display.set_icon(pygame.image.load('./bin/icon.png').convert_alpha())
background = pygame.image.load('./bin/map/background.jpg').convert()
house = [pygame.image.load('./bin/map/village/village0.png').convert_alpha(), pygame.image.load('./bin/map/village/village1.png').convert_alpha(), pygame.image.load('./bin/map/village/village2.png').convert_alpha()]
state = pygame.image.load('./bin/character/state.png').convert_alpha()
stand = pygame.image.load('./bin/character/stand.png').convert_alpha()
walk = [pygame.image.load('./bin/character/walk0.png').convert_alpha(), pygame.image.load('./bin/character/walk1.png').convert_alpha(), pygame.image.load('./bin/character/walk0.png').convert_alpha(), pygame.image.load('./bin/character/walk2.png').convert_alpha()]
attack = [pygame.image.load('./bin/character/attack0.png').convert_alpha(), pygame.image.load('./bin/character/attack1.png').convert_alpha(), pygame.image.load('./bin/character/attack2.png').convert_alpha(), pygame.image.load('./bin/character/attack3.png').convert_alpha(), pygame.image.load('./bin/character/attack4.png').convert_alpha(), pygame.image.load('./bin/character/attack5.png').convert_alpha(), ]
deathimg = pygame.image.load('./bin/character/death.png').convert_alpha()
gameover = pygame.image.load('./bin/character/gameover.png').convert_alpha()
monster0 = pygame.image.load('./bin/monster/monster0.png').convert_alpha()
font = pygame.font.SysFont("arial", 12)
hpc = (250,47,48)
mpc = (4,122,255)
expc = (255,204,1)

class player():
    def __init__(self, stand, walk, state, deathimg, attack):
        self.state = state
        self.standl = stand
        self.standr = pygame.transform.flip(stand , True, False)
        self.walkl = walk
        self.walkr = []
        self.attackl = attack
        self.attackr = []
        self.deathimg = deathimg
        for each in walk:
            self.walkr.append(pygame.transform.flip(each , True, False))
        for each in attack:
            self.attackr.append(pygame.transform.flip(each , True, False))
        self.key_left = False
        self.key_right = False
        self.jump = False
        self.hittedl = False
        self.hittedr = False
        self.attackS = False
        self.heal = False
        self.strike = False
        self.death = False
        self.attackC = 0
        self.x = 300
        self.y = 465
        self.level = 1
        self.hpmax = 100
        self.mpmax = 100
        self.expmax = 100
        self.hp = 100
        self.mp = 100
        self.exp = 0
        self.atk = 10
        self.time = 0
        self.stand = self.standr
        self.walk = self.walkr
        self.attack = self.attackr

    
    def move(self):
        if self.death:
            self.x = self.x
            if self.y <= 485:
                self.y += 4
        else:
            if self.key_left and self.x >= 0:
                if self.attackS:
                    self.x -= 1
                else:
                    self.x -= 3
                self.walk = self.walkl
                self.stand = self.standl
                self.attack = self.attackl
            if self.key_right and self.x <= 800 - self.stand.get_width():
                if self.attackS:
                    self.x += 1
                else:
                    self.x += 3
                self.walk = self.walkr
                self.stand = self.standr
                self.attack = self.attackr
            if self.jump == True:
                self.y -= 6*((self.y-380)/85)
                if self.y <= 400:
                    self.jump = False
            if self.y != 465 and self.jump == False:
                self.y += 6*((self.y-380)/85)
                if self.y > 465:
                    self.y = 465
    def action(self):
        if self.hp >= 0:
            pygame.draw.rect(screen, hpc, ((72,0),((self.hp/self.hpmax)*146,22)), 0)
        if self.mp >= 0:
            pygame.draw.rect(screen, mpc, ((76,22),((self.mp/self.mpmax)*146,22)), 0)
        pygame.draw.rect(screen, expc, ((72,45),((self.exp/self.expmax)*117,7)), 0)
        screen.blit(state, (0,0))
        screen.blit(font.render("Lv."+str(self.level), True, (145,98,52)), (60,51))
        if self.death:
            screen.blit(self.deathimg, (self.x, self.y))
        else:
            if self.strike == True:
                self.attackS = True
            if self.attackS == True:
                self.attackC += 1
                player_img = self.attack[(self.attackC//10)%6]
                screen.blit(player_img, (self.x, self.y))
                if (self.attackC//10)%6 == len(attack)-2:
                    self.attackS = False
                    self.attackC = 0
            elif self.key_left or self.key_right:
                if self.jump == False and self.y == 465:
                    player_img = self.walk[(i//10)%4]
                    screen.blit(player_img, (self.x, self.y))
                else:
                    player_img = self.walk[0]
                    screen.blit(player_img, (self.x, self.y))
            else:
                if self.y != 465:
                    player_img = self.walk[0]
                    screen.blit(player_img, (self.x, self.y))
                else:
                    player_img = self.stand
                    screen.blit(player_img, (self.x, self.y))
            if self.hittedl == True or self.hittedr == True:
                attacked_sound.play()
                pygame.event.set_allowed([pygame.QUIT])
                if self.hittedl == True:
                        self.x += 4
                        screen.blit(player_img, (self.x, self.y))
                        self.time +=1
                else:
                        self.x -= 4
                        screen.blit(player_img, (self.x, self.y))
                        self.time +=1
                if self.time >= 10:
                    self.time = 0
                    self.hittedl = False
                    self.hittedr = False
class monster():
    def __init__(self, pic, hp, atk):
        self.picr = pic
        self.picl = pygame.transform.flip(pic , True, False)
        self.hp = hp
        self.hpmax = hp
        self.atk = atk
        self.pic = self.picl
        self.x = 500
        self.y = 485
        self.death = False
        self.movement = -1
    
    def move(self):
        if random.random()<0.3 and i%30 == 1 :
            self.movement = -self.movement
            if self.pic == self. picl:
                self.pic = self. picr
            else:
                self.pic = self. picl
        if self.x <= 800 - self.pic.get_width() and self.x >= 0:
            self.x += self.movement

    def stateUpdate(self):
        if self.hp > 0:
            pygame.draw.rect(screen, hpc, ((self.x,470),((self.hp/self.hpmax)*80,5)), 0)
            pygame.draw.rect(screen, (0,0,0), ((self.x,470),(80,5)), 1)
            screen.blit(self.pic, (self.x, self.y))

player = player(stand, walk, state, deathimg, attack)
monster = monster(monster0, 20, 5)
clock = pygame.time.Clock()
i = 0

while True:
    i += 1
    if pygame.mixer.music.get_busy()==False:
        pygame.mixer.music.play()
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                player.key_left = True
            elif event.key == pygame.K_RIGHT:
                player.key_right = True
            elif event.key == pygame.K_SPACE and player.y == 465:
                player.jump = True
            elif event.key == pygame.K_z:
                player.attackS = True
            elif event.key == pygame.K_c:
                player.heal = True
            elif event.key == pygame.K_x:
                player.strike = True
        elif event.type == KEYUP:
            if event.key == pygame.K_LEFT:
                player.key_left = False 
            elif event.key == pygame.K_RIGHT:
                player.key_right = False
            elif event.key == pygame.K_c:
                player.heal = False
            elif event.key == pygame.K_x:
                player.strike = False
            #elif event.key == pygame.K_z:
            #       player.attackS = False
    player.move()
    monster.move()
    screen.blit(background, (0,0))
    screen.blit(house[(i//25)%3], (0,0))
    player.action()
    if monster.death == False:
        if player.jump == False:
            if (player.x <= (monster.x+monster.pic.get_width()) and player.x >= monster.x) or ((player.x+player.stand.get_width()) <= (monster.x+monster.pic.get_width()) and (player.x+player.stand.get_width()) >= monster.x):
                if i%30 == 0:
                    player.hp -= monster.atk
                    if player.x < monster.x:
                        player.hittedr = True
                    elif player.x > monster.x:
                        player.hittedl = True
        if player.attackS:
            if player.standl == player.stand and (player.x <= (monster.x+monster.pic.get_width()) and player.x >= monster.x) and i%30 == 0:
                monster.hp -= player.atk
            elif player.standr == player.stand and ((player.x+player.attack[(player.attackC//10)%6].get_width()) <= (monster.x+monster.pic.get_width()) and (player.x+player.attack[(player.attackC//10)%6].get_width()) >= monster.x) and i%30 == 0:
                monster.hp -= player.atk
            if monster.hp <= 0:
                monster.death = True
                deathtime = clock.tick()
                player.exp += 10
        if player.heal:
            if player.mp>10:
                if player.hp < 100:
                    player.hp += player.atk
                else:
                    player.hp = 100
                player.mp -= 10
        if player.strike:
            if player.mp >=20:
                monster.hp = 0
                monster.death = True
                player.mp -= 15
                player.exp += 10
    if player.exp >= 100:
        player.exp = 0
        player.level += 1
        player.hp = player.hpmax
        player.mp = player.mpmax
    if player.hp <= 0:
        player.death = True
        screen.blit(gameover,((800-gameover.get_width())/2,(600-gameover.get_height())/2))
    if monster.death:
        monster.death = False
        monster.hp = 20
        monster.x = random.randint(100, 700)
    monster.stateUpdate()
    time_passed = clock.tick(30)
    pygame.display.update()
